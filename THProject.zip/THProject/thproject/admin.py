from django.contrib import admin

# Register your models here.
from .models import Product
from .models import Categorie
from .models import Tag

class ProductAdmin(admin.ModelAdmin):
	list_display = ('name', 'description', 'category','get_tags_display',)

	# Display Tags in a comma separated string on the Products table under admin
	def get_tags_display(self,obj):
		return ", ".join([tag.name for tag in obj.tags.all()])

	get_tags_display.short_description = 'Tags'
class CategoryAdmin(admin.ModelAdmin):
	list_display = ('name', )
class TagAdmin(admin.ModelAdmin):
	list_display = ('name', )

# Register admins for models
admin.site.register(Product,ProductAdmin)
admin.site.register(Categorie,CategoryAdmin)
admin.site.register(Tag,TagAdmin)