from django.db import models
from django.db.models import Model
# Create your models here.

class Categorie(models.Model):
    name = models.CharField(max_length = 25, unique = True)
    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length = 25, unique = True)
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length = 25, unique = True)
    description = models.TextField(max_length = 30, null = True, blank = True)
    category = models.ForeignKey(Categorie, on_delete=models.CASCADE) # A product belongs to a category
    tags = models.ManyToManyField(Tag)	# A product can have many tags

    def __str__(self):
       return self.description