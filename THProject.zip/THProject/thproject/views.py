from django.shortcuts import render

# relative import of forms
from .models import Product
from .filters import ProductFilter
from django.db.models import Q 


def list_view(request):
    objects = Product.objects.all()

    # Run the list of products through the filters
    my_Filter = ProductFilter(request.GET, queryset=objects) 
    objects = my_Filter.qs

    list_of_lists = []
    # Reconstruct the data into a list of lists so we can render the tags correctly
    for obj in objects:
        tags = ", ".join([tag.name for tag in obj.tags.all()])
        inner_list = [obj.name, obj.description, obj.category, tags]
        list_of_lists.append(inner_list)

    context = {
	'my_Filter': my_Filter,
        'nested_list_data': list_of_lists,
    }
        
    return render(request, "list_view.html", context)